# Git Push Troubleshooting

## Current Issue

The GitHub token is being denied access (403 error). This usually means:

1. **Token doesn't have `repo` scope** - Most common issue
2. **Token has expired** - Tokens can expire
3. **Organization restrictions** - If the repo is in an org with restrictions

## Solution: Create a New Token with Correct Scopes

### Step 1: Create New Token

1. Go to: https://github.com/settings/tokens
2. Click **"Generate new token"** → **"Generate new token (classic)"**
3. **Name**: `meetgenius-ai-push`
4. **Expiration**: Choose your preference (90 days recommended)
5. **Select scopes**: 
   - ✅ **`repo`** (Full control of private repositories) - **REQUIRED**
   - This gives full access to repositories
6. Click **"Generate token"**
7. **Copy the token immediately** (you won't see it again!)

### Step 2: Push with New Token

```bash
cd /Users/varunpatil/meetgenius-ai

# Push to main branch (repository uses main, not master)
git push https://YOUR_NEW_TOKEN@github.com/krishna28240/meetgenius-ai.git master:main
```

Replace `YOUR_NEW_TOKEN` with your new token.

## Alternative: Use GitHub CLI

If you have GitHub CLI installed:

```bash
# Authenticate
gh auth login

# Push
git push -u origin master:main
```

## Alternative: Use SSH

If you have SSH keys set up:

```bash
# Add GitHub to known hosts
ssh-keyscan github.com >> ~/.ssh/known_hosts

# Set remote to SSH
git remote set-url origin git@github.com:krishna28240/meetgenius-ai.git

# Push
git push -u origin master:main
```

## Verify Token Permissions

You can verify your token has the right permissions:

```bash
curl -H "Authorization: token YOUR_TOKEN" https://api.github.com/user
```

If you see your user info, the token works. Then check repo access:

```bash
curl -H "Authorization: token YOUR_TOKEN" \
  https://api.github.com/repos/krishna28240/meetgenius-ai
```

## Current Status

✅ **Code is committed locally**
- Commit: `29da95f`
- Branch: `master`
- 27 files ready to push

❌ **Push blocked** - Need token with `repo` scope

## Quick Command (After Getting New Token)

```bash
cd /Users/varunpatil/meetgenius-ai
git push https://NEW_TOKEN@github.com/krishna28240/meetgenius-ai.git master:main
```

## Note About Branch Names

The repository uses `main` branch, but your local branch is `master`. The command above pushes `master` to `main` on GitHub.

