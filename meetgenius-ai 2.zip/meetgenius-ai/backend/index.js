const express = require('express');
const cors = require('cors');
const axios = require('axios');
const { google } = require('googleapis');
const admin = require('firebase-admin');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Initialize Firestore
let db;
try {
  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.applicationDefault(),
      projectId: process.env.GCP_PROJECT_ID
    });
  }
  db = admin.firestore();
} catch (error) {
  console.warn('Firestore initialization failed:', error.message);
  console.warn('Running without Firestore - data will not be persisted');
  db = null;
}

// LLM Service URL
const LLM_SERVICE_URL = process.env.LLM_SERVICE_URL || 'http://localhost:8080';

/**
 * Get OAuth2 client from user's access token
 */
function getOAuth2Client(accessToken) {
  const oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
  oauth2Client.setCredentials({ access_token: accessToken });
  return oauth2Client;
}

/**
 * Process transcript and extract structured data
 */
app.post('/api/process-transcript', async (req, res) => {
  try {
    const { transcript, title, userId, userEmail } = req.body;

    if (!transcript || typeof transcript !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'Transcript is required'
      });
    }

    console.log(`Processing transcript for user: ${userEmail}`);

    // Call LLM service
    const llmResponse = await axios.post(`${LLM_SERVICE_URL}/extract`, {
      transcript
    });

    if (!llmResponse.data.success) {
      return res.status(500).json({
        success: false,
        error: 'LLM processing failed',
        details: llmResponse.data.error
      });
    }

    const meetingData = llmResponse.data.data;

    // Override title if provided
    if (title) {
      meetingData.title = title;
    }

    // Save to Firestore
    let meetingId = null;
    if (db) {
      const meetingDoc = {
        userId: userId || 'anonymous',
        userEmail: userEmail || null,
        title: meetingData.title,
        summary: meetingData.summary,
        decisions: meetingData.decisions || [],
        actionItems: meetingData.action_items || [],
        participants: meetingData.participants || [],
        keyTopics: meetingData.key_topics || [],
        meetingDate: meetingData.meeting_date,
        meetingDuration: meetingData.meeting_duration,
        transcript: transcript.substring(0, 10000), // Store first 10k chars
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        synced: {
          calendar: false,
          sheets: false,
          email: false
        }
      };

      const docRef = await db.collection('meetings').add(meetingDoc);
      meetingId = docRef.id;
    } else {
      // Generate a temporary ID if Firestore is not available
      meetingId = `temp-${Date.now()}`;
    }

    res.json({
      success: true,
      meetingId: meetingId,
      data: meetingData
    });
  } catch (error) {
    console.error('Process transcript error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * Sync action items to Google Calendar
 */
app.post('/api/sync/calendar', async (req, res) => {
  try {
    const { meetingId, accessToken } = req.body;

    if (!meetingId || !accessToken) {
      return res.status(400).json({
        success: false,
        error: 'meetingId and accessToken are required'
      });
    }

    // Get meeting from Firestore
    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Firestore not available'
      });
    }

    const meetingDoc = await db.collection('meetings').doc(meetingId).get();
    if (!meetingDoc.exists) {
      return res.status(404).json({
        success: false,
        error: 'Meeting not found'
      });
    }

    const meeting = meetingDoc.data();
    const oauth2Client = getOAuth2Client(accessToken);
    const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

    const createdEvents = [];

    // Create calendar events for action items with due dates
    for (const item of meeting.actionItems || []) {
      if (item.due_date && item.due_date !== 'TBD') {
        try {
          const event = {
            summary: `[Action] ${item.task}`,
            description: `Action item from meeting: ${meeting.title}\n\n${meeting.summary}`,
            start: {
              dateTime: `${item.due_date}T09:00:00`,
              timeZone: 'America/Los_Angeles'
            },
            end: {
              dateTime: `${item.due_date}T10:00:00`,
              timeZone: 'America/Los_Angeles'
            },
            reminders: {
              useDefault: false,
              overrides: [
                { method: 'email', minutes: 24 * 60 },
                { method: 'popup', minutes: 30 }
              ]
            }
          };

          // Add attendees if assignee email is available
          if (item.assignee && item.assignee.includes('@')) {
            event.attendees = [{ email: item.assignee }];
          }

          const created = await calendar.events.insert({
            calendarId: 'primary',
            resource: event
          });

          createdEvents.push({
            eventId: created.data.id,
            task: item.task,
            dueDate: item.due_date
          });
        } catch (error) {
          console.error(`Failed to create calendar event for: ${item.task}`, error);
        }
      }
    }

    // Update sync status
    if (db) {
      await db.collection('meetings').doc(meetingId).update({
        'synced.calendar': true,
        calendarEvents: createdEvents
      });
    }

    res.json({
      success: true,
      eventsCreated: createdEvents.length,
      events: createdEvents
    });
  } catch (error) {
    console.error('Calendar sync error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * Sync action items to Google Sheets
 */
app.post('/api/sync/sheets', async (req, res) => {
  try {
    const { meetingId, accessToken, spreadsheetId } = req.body;

    if (!meetingId || !accessToken) {
      return res.status(400).json({
        success: false,
        error: 'meetingId and accessToken are required'
      });
    }

    // Get meeting from Firestore
    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Firestore not available'
      });
    }

    const meetingDoc = await db.collection('meetings').doc(meetingId).get();
    if (!meetingDoc.exists) {
      return res.status(404).json({
        success: false,
        error: 'Meeting not found'
      });
    }

    const meeting = meetingDoc.data();
    const oauth2Client = getOAuth2Client(accessToken);
    const sheets = google.sheets({ version: 'v4', auth: oauth2Client });

    let targetSpreadsheetId = spreadsheetId;

    // Create spreadsheet if not provided
    if (!targetSpreadsheetId) {
      const drive = google.drive({ version: 'v3', auth: oauth2Client });
      const fileMetadata = {
        name: `MeetGenius Action Items - ${new Date().toISOString().split('T')[0]}`,
        mimeType: 'application/vnd.google-apps.spreadsheet'
      };
      const file = await drive.files.create({
        resource: fileMetadata,
        fields: 'id'
      });
      targetSpreadsheetId = file.data.id;

      // Add header row
      await sheets.spreadsheets.values.update({
        spreadsheetId: targetSpreadsheetId,
        range: 'Sheet1!A1:F1',
        valueInputOption: 'RAW',
        resource: {
          values: [['Meeting ID', 'Meeting Title', 'Task', 'Assignee', 'Due Date', 'Confidence', 'Status']]
        }
      });
    }

    // Prepare rows
    const rows = (meeting.actionItems || []).map(item => [
      meetingId,
      meeting.title,
      item.task,
      item.assignee || 'Unassigned',
      item.due_date || 'TBD',
      item.confidence || 0.5,
      'Open'
    ]);

    // Append rows
    await sheets.spreadsheets.values.append({
      spreadsheetId: targetSpreadsheetId,
      range: 'Sheet1!A:F',
      valueInputOption: 'RAW',
      insertDataOption: 'INSERT_ROWS',
      resource: {
        values: rows
      }
    });

    // Update sync status
    if (db) {
      await db.collection('meetings').doc(meetingId).update({
        'synced.sheets': true,
        spreadsheetId: targetSpreadsheetId
      });
    }

    res.json({
      success: true,
      spreadsheetId: targetSpreadsheetId,
      rowsAdded: rows.length
    });
  } catch (error) {
    console.error('Sheets sync error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * Send summary email via Gmail
 */
app.post('/api/sync/email', async (req, res) => {
  try {
    const { meetingId, accessToken, recipientEmails } = req.body;

    if (!meetingId || !accessToken) {
      return res.status(400).json({
        success: false,
        error: 'meetingId and accessToken are required'
      });
    }

    // Get meeting from Firestore
    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Firestore not available'
      });
    }

    const meetingDoc = await db.collection('meetings').doc(meetingId).get();
    if (!meetingDoc.exists) {
      return res.status(404).json({
        success: false,
        error: 'Meeting not found'
      });
    }

    const meeting = meetingDoc.data();
    const oauth2Client = getOAuth2Client(accessToken);
    const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

    // Get user email
    const userInfo = await oauth2Client.getAccessToken();
    const profile = await gmail.users.getProfile({ userId: 'me' });

    // Determine recipients
    const recipients = recipientEmails || 
      (meeting.participants || [])
        .map(p => p.email)
        .filter(email => email && email.includes('@'));

    if (recipients.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No valid recipient emails found'
      });
    }

    // Build HTML email
    const actionItemsHtml = (meeting.actionItems || [])
      .map(item => `
        <li>
          <strong>${item.task}</strong><br>
          Assignee: ${item.assignee || 'Unassigned'}<br>
          Due: ${item.due_date || 'TBD'}<br>
          Priority: ${item.priority || 'medium'}
        </li>
      `).join('');

    const decisionsHtml = (meeting.decisions || [])
      .map(decision => `<li><strong>${decision.decision}</strong><br>${decision.context || ''}</li>`)
      .join('');

    const htmlBody = `
      <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <h2>Meeting Summary: ${meeting.title}</h2>
          
          <h3>Summary</h3>
          <p>${meeting.summary}</p>
          
          <h3>Decisions Made</h3>
          <ul>${decisionsHtml || '<li>No decisions recorded</li>'}</ul>
          
          <h3>Action Items</h3>
          <ul>${actionItemsHtml || '<li>No action items</li>'}</ul>
          
          <h3>Participants</h3>
          <p>${(meeting.participants || []).map(p => p.name || p.email).join(', ') || 'Not specified'}</p>
          
          <hr>
          <p style="color: #666; font-size: 12px;">
            Generated by MeetGenius AI<br>
            Meeting ID: ${meetingId}
          </p>
        </body>
      </html>
    `;

    // Create email message
    const message = [
      `To: ${recipients.join(', ')}`,
      `From: ${profile.data.emailAddress}`,
      `Subject: Meeting Summary: ${meeting.title}`,
      `Content-Type: text/html; charset=utf-8`,
      '',
      htmlBody
    ].join('\n');

    const encodedMessage = Buffer.from(message)
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    await gmail.users.messages.send({
      userId: 'me',
      resource: {
        raw: encodedMessage
      }
    });

    // Update sync status
    if (db) {
      await db.collection('meetings').doc(meetingId).update({
        'synced.email': true,
        emailRecipients: recipients
      });
    }

    res.json({
      success: true,
      recipients: recipients.length,
      sentTo: recipients
    });
  } catch (error) {
    console.error('Email sync error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * Get meeting by ID
 */
app.get('/api/meetings/:meetingId', async (req, res) => {
  try {
    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Firestore not available'
      });
    }

    const { meetingId } = req.params;
    const meetingDoc = await db.collection('meetings').doc(meetingId).get();

    if (!meetingDoc.exists) {
      return res.status(404).json({
        success: false,
        error: 'Meeting not found'
      });
    }

    res.json({
      success: true,
      data: { id: meetingDoc.id, ...meetingDoc.data() }
    });
  } catch (error) {
    console.error('Get meeting error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * Health check
 */
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', service: 'meetgenius-backend' });
});

app.listen(PORT, () => {
  console.log(`MeetGenius Backend running on port ${PORT}`);
  console.log(`LLM Service URL: ${LLM_SERVICE_URL}`);
});

