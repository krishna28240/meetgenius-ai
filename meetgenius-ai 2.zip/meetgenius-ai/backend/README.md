# Backend API

Express.js backend that orchestrates LLM processing, Google API integrations, and Firestore storage.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Create `.env` file with:
   ```
   PORT=3000
   GCP_PROJECT_ID=your-project-id
   LLM_SERVICE_URL=http://localhost:8080
   GOOGLE_CLIENT_ID=your-client-id
   GOOGLE_CLIENT_SECRET=your-client-secret
   GOOGLE_REDIRECT_URI=http://localhost:3000/auth/callback
   ```

3. Set up Firebase Admin SDK:
   ```bash
   gcloud auth application-default login
   ```

## Local Development

```bash
npm run dev
```

## API Endpoints

- `POST /api/process-transcript` - Process transcript and extract structured data
- `POST /api/sync/calendar` - Sync action items to Google Calendar
- `POST /api/sync/sheets` - Sync action items to Google Sheets
- `POST /api/sync/email` - Send summary email via Gmail
- `GET /api/meetings/:meetingId` - Get meeting by ID
- `GET /health` - Health check

## Deployment to Cloud Run

```bash
gcloud builds submit --tag gcr.io/PROJECT-ID/meetgenius-backend
gcloud run deploy meetgenius-backend \
  --image gcr.io/PROJECT-ID/meetgenius-backend \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars LLM_SERVICE_URL=https://meetgenius-llm-xxx.run.app
```

