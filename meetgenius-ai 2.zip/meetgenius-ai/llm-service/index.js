const express = require('express');
const cors = require('cors');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Initialize Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

// Load prompt template
const promptTemplate = fs.readFileSync(
  path.join(__dirname, '../backend/prompts/meeting_extractor.txt'),
  'utf-8'
);

/**
 * Extract structured data from meeting transcript using Gemini
 */
async function extractMeetingData(transcript) {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    
    const fullPrompt = `${promptTemplate}\n\nTRANSCRIPT:\n${transcript}\n\nJSON OUTPUT:`;
    
    const result = await model.generateContent(fullPrompt);
    const response = await result.response;
    const text = response.text();
    
    // Extract JSON from response (handle markdown code blocks)
    let jsonText = text.trim();
    if (jsonText.startsWith('```json')) {
      jsonText = jsonText.replace(/```json\n?/g, '').replace(/```\n?/g, '');
    } else if (jsonText.startsWith('```')) {
      jsonText = jsonText.replace(/```\n?/g, '');
    }
    
    // Parse and validate JSON
    const parsed = JSON.parse(jsonText);
    
    // Validate required fields
    if (!parsed.title || !parsed.summary) {
      throw new Error('Missing required fields in LLM response');
    }
    
    return {
      success: true,
      data: parsed
    };
  } catch (error) {
    console.error('LLM extraction error:', error);
    
    // Retry once on JSON parse error
    if (error.message.includes('JSON') || error.message.includes('parse')) {
      try {
        const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
        const retryPrompt = `${promptTemplate}\n\nTRANSCRIPT:\n${transcript}\n\nIMPORTANT: Return ONLY valid JSON, no markdown, no explanations. JSON OUTPUT:`;
        
        const result = await model.generateContent(retryPrompt);
        const response = await result.response;
        const text = response.text().trim();
        
        let jsonText = text;
        if (jsonText.includes('{')) {
          jsonText = jsonText.substring(jsonText.indexOf('{'));
        }
        if (jsonText.includes('}')) {
          jsonText = jsonText.substring(0, jsonText.lastIndexOf('}') + 1);
        }
        
        const parsed = JSON.parse(jsonText);
        return {
          success: true,
          data: parsed
        };
      } catch (retryError) {
        console.error('Retry failed:', retryError);
      }
    }
    
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Health check endpoint
 */
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', service: 'meetgenius-llm' });
});

/**
 * Process transcript endpoint
 */
app.post('/extract', async (req, res) => {
  try {
    const { transcript } = req.body;
    
    if (!transcript || typeof transcript !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'Transcript is required and must be a string'
      });
    }
    
    if (transcript.length > 50000) {
      return res.status(400).json({
        success: false,
        error: 'Transcript too long (max 50,000 characters)'
      });
    }
    
    console.log(`Processing transcript (${transcript.length} chars)...`);
    const result = await extractMeetingData(transcript);
    
    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Endpoint error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

app.listen(PORT, () => {
  console.log(`MeetGenius LLM Service running on port ${PORT}`);
  console.log(`Gemini API configured: ${process.env.GEMINI_API_KEY ? 'Yes' : 'No'}`);
});

