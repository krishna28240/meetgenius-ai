# LLM Service

Gemini-powered service for extracting structured data from meeting transcripts.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Create `.env` file:
   ```bash
   cp .env.example .env
   ```

3. Add your Gemini API key to `.env`

## Local Development

```bash
npm run dev
```

## Deployment to Cloud Run

1. Build and push to Artifact Registry:
   ```bash
   gcloud builds submit --tag gcr.io/PROJECT-ID/meetgenius-llm
   ```

2. Deploy to Cloud Run:
   ```bash
   gcloud run deploy meetgenius-llm \
     --image gcr.io/PROJECT-ID/meetgenius-llm \
     --region us-central1 \
     --allow-unauthenticated \
     --set-env-vars GEMINI_API_KEY=your-key \
     --memory 2Gi \
     --cpu 2
   ```

## API Endpoints

- `GET /health` - Health check
- `POST /extract` - Extract structured data from transcript
  - Body: `{ "transcript": "..." }`
  - Returns: `{ "success": true, "data": {...} }`

