#!/bin/bash

# Google Cloud SDK Installation Helper for macOS

echo "🔍 Checking for Google Cloud SDK..."

# Check if gcloud is already available
if command -v gcloud &> /dev/null; then
    echo "✅ gcloud is already installed!"
    gcloud --version
    exit 0
fi

# Check common installation locations
if [ -f "$HOME/google-cloud-sdk/bin/gcloud" ]; then
    echo "✅ Found Google Cloud SDK at $HOME/google-cloud-sdk"
    echo "Adding to PATH..."
    export PATH="$HOME/google-cloud-sdk/bin:$PATH"
    
    # Check if it's in .zshrc
    if ! grep -q "google-cloud-sdk" "$HOME/.zshrc" 2>/dev/null; then
        echo ""
        echo "📝 Add this to your ~/.zshrc file:"
        echo ""
        echo "# Google Cloud SDK"
        echo 'export PATH="$HOME/google-cloud-sdk/bin:$PATH"'
        echo ""
        echo "Then run: source ~/.zshrc"
    fi
    exit 0
fi

echo "❌ Google Cloud SDK not found"
echo ""
echo "To install Google Cloud SDK:"
echo ""
echo "Option 1: Using Homebrew (Recommended)"
echo "  brew install --cask google-cloud-sdk"
echo ""
echo "Option 2: Using the installer"
echo "  curl https://sdk.cloud.google.com | bash"
echo "  exec -l \$SHELL"
echo ""
echo "Option 3: Download from"
echo "  https://cloud.google.com/sdk/docs/install"
echo ""
echo "After installation, run:"
echo "  gcloud init"
echo "  gcloud auth login"
echo "  gcloud auth application-default login"

