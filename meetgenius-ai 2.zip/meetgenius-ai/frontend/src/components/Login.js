import React, { useEffect } from 'react';
import './Login.css';

const GOOGLE_CLIENT_ID = process.env.REACT_APP_GOOGLE_CLIENT_ID || 
  '586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com';

function Login({ onSignIn }) {
  useEffect(() => {
    const initializeGoogleSignIn = () => {
      if (window.google && window.google.accounts) {
        window.google.accounts.id.renderButton(
          document.getElementById('google-signin-button'),
          {
            theme: 'outline',
            size: 'large',
            width: 250,
            text: 'signin_with'
          }
        );
      }
    };

    if (window.google) {
      initializeGoogleSignIn();
    } else {
      const checkInterval = setInterval(() => {
        if (window.google) {
          initializeGoogleSignIn();
          clearInterval(checkInterval);
        }
      }, 100);
    }
  }, []);

  return (
    <div className="login-container">
      <div className="login-card">
        <h2>Welcome to MeetGenius AI</h2>
        <p className="subtitle">Intelligent Meeting Summarizer</p>
        <p className="description">
          Transform your Google Meet transcripts into actionable summaries, 
          decisions, and task lists. Sync with Google Calendar, Sheets, and Gmail.
        </p>
        <div id="google-signin-button" className="signin-button-container"></div>
        <p className="privacy-note">
          By signing in, you agree to grant access to Calendar, Gmail, and Sheets 
          for syncing meeting summaries and action items.
        </p>
      </div>
    </div>
  );
}

export default Login;

