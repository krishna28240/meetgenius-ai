import React from 'react';
import './SummaryDisplay.css';

function SummaryDisplay({ data, onReset }) {
  const formatDate = (dateStr) => {
    if (!dateStr || dateStr === 'TBD') return 'Not specified';
    try {
      return new Date(dateStr).toLocaleDateString();
    } catch {
      return dateStr;
    }
  };

  const getConfidenceColor = (confidence) => {
    if (confidence >= 0.7) return '#28a745';
    if (confidence >= 0.4) return '#ffc107';
    return '#dc3545';
  };

  return (
    <div className="summary-container">
      <div className="summary-header">
        <h2>{data.title || 'Meeting Summary'}</h2>
        <button onClick={onReset} className="reset-btn">Process New Transcript</button>
      </div>

      <div className="summary-card">
        <h3>Summary</h3>
        <p className="summary-text">{data.summary}</p>
      </div>

      {data.decisions && data.decisions.length > 0 && (
        <div className="summary-card">
          <h3>Decisions Made</h3>
          <ul className="decisions-list">
            {data.decisions.map((decision, idx) => (
              <li key={idx}>
                <strong>{decision.decision}</strong>
                {decision.context && <p className="context">{decision.context}</p>}
              </li>
            ))}
          </ul>
        </div>
      )}

      {data.action_items && data.action_items.length > 0 && (
        <div className="summary-card">
          <h3>Action Items</h3>
          <div className="action-items-grid">
            {data.action_items.map((item, idx) => (
              <div key={idx} className="action-item">
                <div className="action-header">
                  <span className="action-task">{item.task}</span>
                  <span
                    className="confidence-badge"
                    style={{ backgroundColor: getConfidenceColor(item.confidence || 0.5) }}
                  >
                    {Math.round((item.confidence || 0.5) * 100)}% confidence
                  </span>
                </div>
                <div className="action-details">
                  <div className="detail-item">
                    <strong>Assignee:</strong> {item.assignee || 'Unassigned'}
                  </div>
                  <div className="detail-item">
                    <strong>Due Date:</strong> {formatDate(item.due_date)}
                  </div>
                  <div className="detail-item">
                    <strong>Priority:</strong> {item.priority || 'medium'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {data.participants && data.participants.length > 0 && (
        <div className="summary-card">
          <h3>Participants</h3>
          <div className="participants-list">
            {data.participants.map((participant, idx) => (
              <div key={idx} className="participant">
                <strong>{participant.name || participant.email}</strong>
                {participant.email && participant.email !== participant.name && (
                  <span className="email">{participant.email}</span>
                )}
                {participant.role && (
                  <span className="role">{participant.role}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {data.key_topics && data.key_topics.length > 0 && (
        <div className="summary-card">
          <h3>Key Topics</h3>
          <div className="topics-list">
            {data.key_topics.map((topic, idx) => (
              <span key={idx} className="topic-tag">{topic}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default SummaryDisplay;

