import React, { useState } from 'react';
import './TranscriptUpload.css';

function TranscriptUpload({ onProcess, loading }) {
  const [transcript, setTranscript] = useState('');
  const [title, setTitle] = useState('');
  const [file, setFile] = useState(null);

  const handleFileUpload = (e) => {
    const uploadedFile = e.target.files[0];
    if (uploadedFile) {
      setFile(uploadedFile);
      const reader = new FileReader();
      reader.onload = (event) => {
        setTranscript(event.target.result);
      };
      reader.readAsText(uploadedFile);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (transcript.trim()) {
      onProcess(transcript, title || undefined);
    }
  };

  return (
    <div className="upload-container">
      <div className="upload-card">
        <h2>Upload Meeting Transcript</h2>
        <p className="instruction">
          Paste your Google Meet transcript or upload a .txt or .vtt file
        </p>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="title">Meeting Title (Optional)</label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Weekly Team Sync - Jan 15"
              className="form-input"
            />
          </div>

          <div className="form-group">
            <label htmlFor="file">Upload File</label>
            <input
              type="file"
              id="file"
              accept=".txt,.vtt"
              onChange={handleFileUpload}
              className="file-input"
            />
            {file && <span className="file-name">{file.name}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="transcript">Or Paste Transcript</label>
            <textarea
              id="transcript"
              value={transcript}
              onChange={(e) => setTranscript(e.target.value)}
              placeholder="Paste your meeting transcript here..."
              rows="15"
              className="form-textarea"
              required
            />
            <div className="char-count">
              {transcript.length} characters
            </div>
          </div>

          <button
            type="submit"
            disabled={!transcript.trim() || loading}
            className="submit-btn"
          >
            {loading ? 'Processing...' : 'Generate Summary'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default TranscriptUpload;

