import React, { useState } from 'react';
import './SyncPanel.css';

function SyncPanel({ onSync, loading, hasAccessToken }) {
  const [syncOptions, setSyncOptions] = useState({
    calendar: false,
    sheets: false,
    email: false
  });

  const handleToggle = (option) => {
    setSyncOptions(prev => ({
      ...prev,
      [option]: !prev[option]
    }));
  };

  const handleSync = () => {
    const hasAnySelected = Object.values(syncOptions).some(v => v);
    if (!hasAnySelected) {
      alert('Please select at least one service to sync');
      return;
    }
    onSync(syncOptions);
  };

  if (!hasAccessToken) {
    return (
      <div className="sync-panel">
        <div className="warning-message">
          ⚠️ Please grant API access permissions to sync with Google services.
          The access token request should appear automatically after sign-in.
        </div>
      </div>
    );
  }

  return (
    <div className="sync-panel">
      <div className="sync-card">
        <h3>Sync Actions</h3>
        <p className="sync-description">
          Select the services you want to sync your meeting summary and action items to:
        </p>

        <div className="sync-options">
          <label className="sync-option">
            <input
              type="checkbox"
              checked={syncOptions.calendar}
              onChange={() => handleToggle('calendar')}
            />
            <div className="option-content">
              <strong>📅 Google Calendar</strong>
              <span>Create calendar events for action items with due dates</span>
            </div>
          </label>

          <label className="sync-option">
            <input
              type="checkbox"
              checked={syncOptions.sheets}
              onChange={() => handleToggle('sheets')}
            />
            <div className="option-content">
              <strong>📊 Google Sheets</strong>
              <span>Append action items to a tracking spreadsheet</span>
            </div>
          </label>

          <label className="sync-option">
            <input
              type="checkbox"
              checked={syncOptions.email}
              onChange={() => handleToggle('email')}
            />
            <div className="option-content">
              <strong>✉️ Gmail</strong>
              <span>Send summary email to all participants</span>
            </div>
          </label>
        </div>

        <button
          onClick={handleSync}
          disabled={loading || !Object.values(syncOptions).some(v => v)}
          className="sync-btn"
        >
          {loading ? 'Syncing...' : 'Run Sync Now'}
        </button>
      </div>
    </div>
  );
}

export default SyncPanel;

