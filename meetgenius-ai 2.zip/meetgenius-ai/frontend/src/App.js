import React, { useState, useEffect } from 'react';
import './App.css';
import Login from './components/Login';
import TranscriptUpload from './components/TranscriptUpload';
import SummaryDisplay from './components/SummaryDisplay';
import SyncPanel from './components/SyncPanel';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000';
const GOOGLE_CLIENT_ID = process.env.REACT_APP_GOOGLE_CLIENT_ID || 
  '586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com';

function App() {
  const [user, setUser] = useState(null);
  const [accessToken, setAccessToken] = useState(null);
  const [meetingData, setMeetingData] = useState(null);
  const [meetingId, setMeetingId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Load Google Sign-In API
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);

    script.onload = () => {
      if (window.google) {
        window.google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: handleCredentialResponse
        });
      }
    };

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const handleCredentialResponse = (response) => {
    // Decode JWT token (simplified - in production use proper JWT library)
    try {
      const base64Url = response.credential.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(atob(base64).split('').map(c => {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));

      const userData = JSON.parse(jsonPayload);
      setUser({
        email: userData.email,
        name: userData.name,
        picture: userData.picture
      });

      // Get access token for Google APIs
      getAccessToken();
    } catch (error) {
      console.error('Error decoding credential:', error);
      setError('Failed to sign in');
    }
  };

  const getAccessToken = async () => {
    try {
      const tokenClient = window.google.accounts.oauth2.initTokenClient({
        client_id: GOOGLE_CLIENT_ID,
        scope: 'https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/gmail.send https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive',
        callback: (tokenResponse) => {
          setAccessToken(tokenResponse.access_token);
        }
      });
      tokenClient.requestAccessToken();
    } catch (error) {
      console.error('Error getting access token:', error);
      setError('Failed to get API access');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setAccessToken(null);
    setMeetingData(null);
    setMeetingId(null);
    if (window.google) {
      window.google.accounts.id.disableAutoSelect();
    }
  };

  const handleProcessTranscript = async (transcript, title) => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`${API_BASE_URL}/api/process-transcript`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          transcript,
          title,
          userId: user?.email,
          userEmail: user?.email
        })
      });

      const data = await response.json();

      if (data.success) {
        setMeetingData(data.data);
        setMeetingId(data.meetingId);
      } else {
        setError(data.error || 'Failed to process transcript');
      }
    } catch (err) {
      setError(err.message || 'Network error');
    } finally {
      setLoading(false);
    }
  };

  const handleSync = async (syncOptions) => {
    if (!meetingId || !accessToken) {
      setError('Please sign in and process a transcript first');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const syncPromises = [];

      if (syncOptions.calendar) {
        syncPromises.push(
          fetch(`${API_BASE_URL}/api/sync/calendar`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ meetingId, accessToken })
          })
        );
      }

      if (syncOptions.sheets) {
        syncPromises.push(
          fetch(`${API_BASE_URL}/api/sync/sheets`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ meetingId, accessToken })
          })
        );
      }

      if (syncOptions.email) {
        syncPromises.push(
          fetch(`${API_BASE_URL}/api/sync/email`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ meetingId, accessToken })
          })
        );
      }

      const results = await Promise.allSettled(syncPromises);
      const successful = results.filter(r => r.status === 'fulfilled').length;

      if (successful === syncPromises.length) {
        alert(`Successfully synced ${successful} service(s)!`);
      } else {
        setError('Some sync operations failed');
      }
    } catch (err) {
      setError(err.message || 'Sync failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>MeetGenius AI</h1>
        {user && (
          <div className="user-info">
            <img src={user.picture} alt={user.name} className="user-avatar" />
            <span>{user.name}</span>
            <button onClick={handleLogout} className="logout-btn">Logout</button>
          </div>
        )}
      </header>

      <main className="App-main">
        {!user ? (
          <Login onSignIn={handleCredentialResponse} />
        ) : (
          <>
            {error && <div className="error-message">{error}</div>}
            
            {!meetingData ? (
              <TranscriptUpload
                onProcess={handleProcessTranscript}
                loading={loading}
              />
            ) : (
              <>
                <SummaryDisplay
                  data={meetingData}
                  onReset={() => {
                    setMeetingData(null);
                    setMeetingId(null);
                  }}
                />
                <SyncPanel
                  onSync={handleSync}
                  loading={loading}
                  hasAccessToken={!!accessToken}
                />
              </>
            )}
          </>
        )}
      </main>
    </div>
  );
}

export default App;

