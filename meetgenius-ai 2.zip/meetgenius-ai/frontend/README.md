# Frontend - MeetGenius AI

React frontend application for uploading transcripts and viewing meeting summaries.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Create `.env` file:
   ```
   REACT_APP_API_URL=http://localhost:3000
   REACT_APP_GOOGLE_CLIENT_ID=586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com
   ```

3. Start development server:
   ```bash
   npm start
   ```

## Build for Production

```bash
npm run build
```

## Deployment

### Firebase Hosting

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
npm run build
firebase deploy
```

### Cloud Run (Static)

```bash
npm run build
gcloud run deploy meetgenius-frontend \
  --source . \
  --region us-central1 \
  --allow-unauthenticated
```

## Features

- Google OAuth authentication
- Transcript upload (text or file)
- AI-powered summary display
- Action items with confidence scores
- Sync to Google Calendar, Sheets, and Gmail
