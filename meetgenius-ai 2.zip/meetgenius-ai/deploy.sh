#!/bin/bash

# MeetGenius AI Deployment Script
# This script deploys all services to Google Cloud Run

set -e

PROJECT_ID=${GCP_PROJECT_ID:-"meetgenius-ai"}
REGION=${GCP_REGION:-"us-central1"}

echo "🚀 Deploying MeetGenius AI to GCP..."
echo "Project: $PROJECT_ID"
echo "Region: $REGION"

# Set project
gcloud config set project $PROJECT_ID

# Enable required APIs
echo "📦 Enabling required APIs..."
gcloud services enable \
  run.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com \
  secretmanager.googleapis.com \
  firestore.googleapis.com \
  sheets.googleapis.com \
  gmail.googleapis.com \
  calendar-json.googleapis.com \
  drive.googleapis.com

# Build and deploy LLM service
echo "🤖 Building LLM service..."
cd llm-service
gcloud builds submit --tag gcr.io/$PROJECT_ID/meetgenius-llm

echo "🚀 Deploying LLM service..."
gcloud run deploy meetgenius-llm \
  --image gcr.io/$PROJECT_ID/meetgenius-llm \
  --region $REGION \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 2 \
  --set-secrets GEMINI_API_KEY=gemini-api-key:latest

LLM_URL=$(gcloud run services describe meetgenius-llm --region $REGION --format 'value(status.url)')
echo "✅ LLM Service deployed: $LLM_URL"

# Build and deploy Backend
echo "🔧 Building Backend service..."
cd ../backend
gcloud builds submit --tag gcr.io/$PROJECT_ID/meetgenius-backend

echo "🚀 Deploying Backend service..."
gcloud run deploy meetgenius-backend \
  --image gcr.io/$PROJECT_ID/meetgenius-backend \
  --region $REGION \
  --allow-unauthenticated \
  --memory 1Gi \
  --cpu 1 \
  --set-env-vars LLM_SERVICE_URL=$LLM_URL,GCP_PROJECT_ID=$PROJECT_ID \
  --set-secrets GOOGLE_CLIENT_ID=google-client-id:latest,GOOGLE_CLIENT_SECRET=google-client-secret:latest

BACKEND_URL=$(gcloud run services describe meetgenius-backend --region $REGION --format 'value(status.url)')
echo "✅ Backend Service deployed: $BACKEND_URL"

# Deploy Frontend
echo "🎨 Building Frontend..."
cd ../frontend
npm run build

echo "🚀 Deploying Frontend..."
gcloud run deploy meetgenius-frontend \
  --source . \
  --region $REGION \
  --allow-unauthenticated \
  --set-env-vars REACT_APP_API_URL=$BACKEND_URL

FRONTEND_URL=$(gcloud run services describe meetgenius-frontend --region $REGION --format 'value(status.url)')
echo "✅ Frontend deployed: $FRONTEND_URL"

echo ""
echo "🎉 Deployment complete!"
echo "Frontend URL: $FRONTEND_URL"
echo "Backend URL: $BACKEND_URL"
echo "LLM Service URL: $LLM_URL"
echo ""
echo "⚠️  Don't forget to:"
echo "1. Update OAuth redirect URIs in Google Cloud Console"
echo "2. Store secrets in Secret Manager"
echo "3. Configure Firestore database"

