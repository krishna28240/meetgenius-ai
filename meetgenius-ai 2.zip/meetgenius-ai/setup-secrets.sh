#!/bin/bash

# Script to set up secrets in Google Secret Manager

set -e

PROJECT_ID=${GCP_PROJECT_ID:-"meetgenius-ai"}

echo "🔐 Setting up secrets in Secret Manager..."

# Gemini API Key
GEMINI_KEY="AIzaSyCpTFDBuJn2hNY8d-XMihkn4GBVWapU2w4"

# Create secrets
echo "Creating Gemini API key secret..."
echo -n "$GEMINI_KEY" | gcloud secrets create gemini-api-key \
  --data-file=- \
  --project=$PROJECT_ID || \
  echo -n "$GEMINI_KEY" | gcloud secrets versions add gemini-api-key \
  --data-file=- \
  --project=$PROJECT_ID

echo "Creating Google OAuth Client ID secret..."
echo -n "586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com" | \
  gcloud secrets create google-client-id \
  --data-file=- \
  --project=$PROJECT_ID || \
  echo -n "586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com" | \
  gcloud secrets versions add google-client-id \
  --data-file=- \
  --project=$PROJECT_ID

echo "Creating Google OAuth Client Secret..."
echo -n "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" | \
  gcloud secrets create google-client-secret \
  --data-file=- \
  --project=$PROJECT_ID || \
  echo -n "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" | \
  gcloud secrets versions add google-client-secret \
  --data-file=- \
  --project=$PROJECT_ID

echo "✅ Secrets created successfully!"
echo ""
echo "Granting Cloud Run service account access..."
SERVICE_ACCOUNT="${PROJECT_ID}@appspot.gserviceaccount.com"

gcloud secrets add-iam-policy-binding gemini-api-key \
  --member="serviceAccount:${SERVICE_ACCOUNT}" \
  --role="roles/secretmanager.secretAccessor" \
  --project=$PROJECT_ID

gcloud secrets add-iam-policy-binding google-client-id \
  --member="serviceAccount:${SERVICE_ACCOUNT}" \
  --role="roles/secretmanager.secretAccessor" \
  --project=$PROJECT_ID

gcloud secrets add-iam-policy-binding google-client-secret \
  --member="serviceAccount:${SERVICE_ACCOUNT}" \
  --role="roles/secretmanager.secretAccessor" \
  --project=$PROJECT_ID

echo "✅ IAM permissions granted!"

