#!/bin/bash

# MeetGenius AI - Complete Deployment Script
# Run this script to deploy all services to GCP

set -e

PROJECT_ID="meetgenius-ai"
REGION="us-central1"
GEMINI_KEY="AIzaSyCpTFDBuJn2hNY8d-XMihkn4GBVWapU2w4"

echo "🚀 MeetGenius AI - Complete Deployment"
echo "======================================"
echo "Project: $PROJECT_ID"
echo "Region: $REGION"
echo ""

# Check if gcloud is installed
if ! command -v gcloud &> /dev/null; then
    echo "❌ Error: gcloud command not found"
    echo ""
    echo "Please install Google Cloud SDK first:"
    echo ""
    echo "Option 1: Using Homebrew"
    echo "  brew install --cask google-cloud-sdk"
    echo ""
    echo "Option 2: Using the installer"
    echo "  curl https://sdk.cloud.google.com | bash"
    echo "  exec -l \$SHELL"
    echo ""
    echo "Or run: ./install-gcloud.sh"
    echo ""
    exit 1
fi

# Try to add Google Cloud SDK to PATH if it exists in home directory
if [ -f "$HOME/google-cloud-sdk/bin/gcloud" ]; then
    export PATH="$HOME/google-cloud-sdk/bin:$PATH"
fi

echo "✅ Using gcloud: $(which gcloud)"
echo ""

# Step 1: Set project
echo "📌 Step 1: Setting GCP project..."
gcloud config set project $PROJECT_ID
echo "✅ Project set to $PROJECT_ID"
echo ""

# Step 2: Enable APIs
echo "📦 Step 2: Enabling required APIs..."
gcloud services enable \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com \
  iam.googleapis.com \
  sheets.googleapis.com \
  gmail.googleapis.com \
  calendar-json.googleapis.com \
  drive.googleapis.com \
  secretmanager.googleapis.com \
  firestore.googleapis.com \
  aiplatform.googleapis.com \
  --project=$PROJECT_ID
echo "✅ APIs enabled"
echo ""

# Step 3: Create Firestore database (if not exists)
echo "💾 Step 3: Checking Firestore database..."
if ! gcloud firestore databases list --project=$PROJECT_ID 2>/dev/null | grep -q "default"; then
  echo "Creating Firestore database..."
  gcloud firestore databases create \
    --location=us-central1 \
    --type=firestore-native \
    --project=$PROJECT_ID || echo "Database may already exist or creation failed"
else
  echo "✅ Firestore database already exists"
fi
echo ""

# Step 4: Set up secrets
echo "🔐 Step 4: Setting up secrets in Secret Manager..."

# Gemini API Key
echo "Creating Gemini API key secret..."
echo -n "$GEMINI_KEY" | gcloud secrets create gemini-api-key \
  --data-file=- \
  --project=$PROJECT_ID 2>/dev/null || \
  echo -n "$GEMINI_KEY" | gcloud secrets versions add gemini-api-key \
  --data-file=- \
  --project=$PROJECT_ID
echo "✅ Gemini API key stored"

# OAuth Client ID
echo "Creating Google OAuth Client ID secret..."
echo -n "586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com" | \
  gcloud secrets create google-client-id \
  --data-file=- \
  --project=$PROJECT_ID 2>/dev/null || \
  echo -n "586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com" | \
  gcloud secrets versions add google-client-id \
  --data-file=- \
  --project=$PROJECT_ID
echo "✅ OAuth Client ID stored"

# OAuth Client Secret
echo "Creating Google OAuth Client Secret..."
echo -n "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" | \
  gcloud secrets create google-client-secret \
  --data-file=- \
  --project=$PROJECT_ID 2>/dev/null || \
  echo -n "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" | \
  gcloud secrets versions add google-client-secret \
  --data-file=- \
  --project=$PROJECT_ID
echo "✅ OAuth Client Secret stored"
echo ""

# Grant service account access to secrets
echo "Granting Cloud Run service account access to secrets..."
SERVICE_ACCOUNT="${PROJECT_ID}@appspot.gserviceaccount.com"

gcloud secrets add-iam-policy-binding gemini-api-key \
  --member="serviceAccount:${SERVICE_ACCOUNT}" \
  --role="roles/secretmanager.secretAccessor" \
  --project=$PROJECT_ID 2>/dev/null || echo "IAM binding may already exist"

gcloud secrets add-iam-policy-binding google-client-id \
  --member="serviceAccount:${SERVICE_ACCOUNT}" \
  --role="roles/secretmanager.secretAccessor" \
  --project=$PROJECT_ID 2>/dev/null || echo "IAM binding may already exist"

gcloud secrets add-iam-policy-binding google-client-secret \
  --member="serviceAccount:${SERVICE_ACCOUNT}" \
  --role="roles/secretmanager.secretAccessor" \
  --project=$PROJECT_ID 2>/dev/null || echo "IAM binding may already exist"
echo "✅ IAM permissions granted"
echo ""

# Step 5: Deploy LLM Service
echo "🤖 Step 5: Deploying LLM Service..."
cd llm-service
gcloud builds submit --tag gcr.io/$PROJECT_ID/meetgenius-llm --project=$PROJECT_ID

gcloud run deploy meetgenius-llm \
  --image gcr.io/$PROJECT_ID/meetgenius-llm \
  --region $REGION \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 2 \
  --set-secrets GEMINI_API_KEY=gemini-api-key:latest \
  --project=$PROJECT_ID \
  --quiet

LLM_URL=$(gcloud run services describe meetgenius-llm --region $REGION --format 'value(status.url)' --project=$PROJECT_ID)
echo "✅ LLM Service deployed: $LLM_URL"
cd ..
echo ""

# Step 6: Deploy Backend
echo "🔧 Step 6: Deploying Backend Service..."
cd backend
gcloud builds submit --tag gcr.io/$PROJECT_ID/meetgenius-backend --project=$PROJECT_ID

gcloud run deploy meetgenius-backend \
  --image gcr.io/$PROJECT_ID/meetgenius-backend \
  --region $REGION \
  --allow-unauthenticated \
  --memory 1Gi \
  --cpu 1 \
  --set-env-vars LLM_SERVICE_URL=$LLM_URL,GCP_PROJECT_ID=$PROJECT_ID \
  --set-secrets GOOGLE_CLIENT_ID=google-client-id:latest,GOOGLE_CLIENT_SECRET=google-client-secret:latest \
  --project=$PROJECT_ID \
  --quiet

BACKEND_URL=$(gcloud run services describe meetgenius-backend --region $REGION --format 'value(status.url)' --project=$PROJECT_ID)
echo "✅ Backend Service deployed: $BACKEND_URL"
cd ..
echo ""

# Step 7: Deploy Frontend
echo "🎨 Step 7: Deploying Frontend..."
cd frontend

# Create .env.production
cat > .env.production << EOF
REACT_APP_API_URL=$BACKEND_URL
REACT_APP_GOOGLE_CLIENT_ID=586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com
EOF

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
  echo "Installing frontend dependencies..."
  npm install
fi

# Build
echo "Building frontend..."
npm run build

# Deploy
gcloud run deploy meetgenius-frontend \
  --source . \
  --region $REGION \
  --allow-unauthenticated \
  --project=$PROJECT_ID \
  --quiet

FRONTEND_URL=$(gcloud run services describe meetgenius-frontend --region $REGION --format 'value(status.url)' --project=$PROJECT_ID)
echo "✅ Frontend deployed: $FRONTEND_URL"
cd ..
echo ""

# Step 8: Summary
echo "======================================"
echo "🎉 Deployment Complete!"
echo "======================================"
echo ""
echo "Service URLs:"
echo "  Frontend: $FRONTEND_URL"
echo "  Backend:  $BACKEND_URL"
echo "  LLM:      $LLM_URL"
echo ""
echo "⚠️  IMPORTANT: Update OAuth Redirect URIs"
echo "1. Go to: https://console.cloud.google.com/apis/credentials?project=$PROJECT_ID"
echo "2. Edit OAuth 2.0 Client ID: 586594156466-03b76ajqn70gkbsoia34g887edb6kqlm"
echo "3. Add to Authorized redirect URIs:"
echo "   - $FRONTEND_URL"
echo "   - http://localhost:3000 (for local testing)"
echo "4. Add to Authorized JavaScript origins:"
echo "   - $FRONTEND_URL"
echo "   - http://localhost:3000"
echo ""
echo "🧪 Test your deployment:"
echo "1. Visit: $FRONTEND_URL"
echo "2. Sign in with Google"
echo "3. Upload a sample transcript from the samples/ folder"
echo "4. Test syncing to Calendar, Sheets, and Gmail"
echo ""
