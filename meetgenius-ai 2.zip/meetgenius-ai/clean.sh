#!/bin/bash

# MeetGenius AI - Project Cleanup Script
# Removes build artifacts, dependencies, and temporary files

set -e

echo "🧹 Cleaning MeetGenius AI project..."
echo ""

# Remove node_modules
echo "Removing node_modules directories..."
find . -type d -name "node_modules" -prune -exec rm -rf {} + 2>/dev/null || true
echo "✅ Removed node_modules"

# Remove build artifacts
echo "Removing build artifacts..."
rm -rf frontend/build frontend/dist 2>/dev/null || true
rm -rf backend/dist backend/build 2>/dev/null || true
rm -rf llm-service/dist llm-service/build 2>/dev/null || true
echo "✅ Removed build directories"

# Remove OS files
echo "Removing OS files..."
find . -name ".DS_Store" -type f -delete 2>/dev/null || true
find . -name "Thumbs.db" -type f -delete 2>/dev/null || true
echo "✅ Removed OS files"

# Remove log files
echo "Removing log files..."
find . -name "*.log" -type f -not -path "./node_modules/*" -delete 2>/dev/null || true
echo "✅ Removed log files"

# Remove temporary files
echo "Removing temporary files..."
find . -name "*.swp" -o -name "*.swo" -o -name "*~" -type f -not -path "./node_modules/*" -delete 2>/dev/null || true
echo "✅ Removed temporary files"

# Remove cache directories
echo "Removing cache directories..."
rm -rf .cache coverage .nyc_output 2>/dev/null || true
echo "✅ Removed cache directories"

# Remove package-lock files (optional - comment out if you want to keep them)
echo "Removing package-lock.json files..."
find . -name "package-lock.json" -type f -not -path "./node_modules/*" -delete 2>/dev/null || true
echo "✅ Removed package-lock.json files"

# Remove local env files (keep .env.example)
echo "Removing local environment files..."
find . -name ".env.local" -o -name ".env.*.local" -type f -not -path "./node_modules/*" -delete 2>/dev/null || true
echo "✅ Removed local env files"

# Remove IDE directories
echo "Removing IDE directories..."
rm -rf .vscode .idea 2>/dev/null || true
echo "✅ Removed IDE directories"

echo ""
echo "✨ Project cleaned successfully!"
echo ""
echo "To restore dependencies, run:"
echo "  cd frontend && npm install"
echo "  cd ../backend && npm install"
echo "  cd ../llm-service && npm install"

