# MeetGenius AI

MeetGenius AI is an intelligent meeting summarizer that converts Google Meet transcripts into actionable summaries, decisions, and task lists — and syncs them with Google Calendar, Gmail, and Google Sheets.

## 🚀 Quick Start

**For local development**, see [QUICKSTART.md](./QUICKSTART.md)

**For GCP deployment**, see [DEPLOYMENT.md](./DEPLOYMENT.md)

## 📁 Project Structure

```
meetgenius-ai/
├── frontend/          # React UI (login, transcript upload, results UI)
├── backend/           # Node.js backend (API orchestrator, OAuth, Google API actions)
├── llm-service/       # Gemini LLM service (Cloud Run)
├── samples/           # Sample meeting transcripts for testing
├── deploy.sh          # Automated deployment script
├── setup-secrets.sh   # Secret Manager setup script
└── docs/              # Architecture and project documentation
```

## ✨ Features

- 🤖 **AI-Powered Summarization**: Uses Gemini API to extract structured data from transcripts
- 📅 **Google Calendar Sync**: Creates calendar events for action items with due dates
- 📊 **Google Sheets Integration**: Maintains action item tracking spreadsheet
- ✉️ **Gmail Integration**: Sends formatted summary emails to participants
- 💾 **Firestore Storage**: Persistent storage for all meeting data
- 🎯 **Confidence Scores**: Shows extraction confidence for transparency
- 🔐 **Secure OAuth**: Google OAuth 2.0 authentication

## 🛠 Tech Stack

| Component | Technology |
|-----------|-----------|
| Frontend | React 18, CSS3 |
| Backend | Node.js, Express.js |
| LLM | Google Gemini API |
| Database | Google Firestore |
| Auth | Google OAuth 2.0 |
| Deployment | Google Cloud Run |
| Secrets | Google Secret Manager |

## 📋 Prerequisites

1. **GCP Project** with billing enabled
2. **Gemini API Key** ([Get one here](https://makersuite.google.com/app/apikey))
3. **OAuth 2.0 Credentials** (already provided):
   - Client ID: `586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com`
   - Client Secret: `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`

## 🏗 Architecture

```
┌─────────────────┐
│  React Frontend │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Backend API    │
│  (Express.js)   │
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
    ▼         ▼
┌─────────┐ ┌──────────────┐
│ LLM     │ │  Firestore   │
│ Service │ │  Database    │
└─────────┘ └──────────────┘
    │
    ▼
┌─────────────────────────────┐
│      Google APIs            │
│  Calendar | Sheets | Gmail  │
└─────────────────────────────┘
```

See [ARCHITECTURE.md](./ARCHITECTURE.md) for detailed architecture documentation.

## 📚 Documentation

- [QUICKSTART.md](./QUICKSTART.md) - Get started locally in 5 minutes
- [DEPLOYMENT_STEPS.md](./DEPLOYMENT_STEPS.md) - **Complete step-by-step GCP deployment guide**
- [DEPLOYMENT.md](./DEPLOYMENT.md) - GCP deployment overview
- [ARCHITECTURE.md](./ARCHITECTURE.md) - System architecture and design decisions
- [PROJECT_SUMMARY.md](./PROJECT_SUMMARY.md) - Use case, design, and impact

## 🧪 Testing

Sample transcripts are available in the `samples/` directory:
- `sample-transcript-1.txt` - Team sync meeting
- `sample-transcript-2.txt` - Product review meeting
- `sample-transcript-3.txt` - Sprint planning meeting

## 🔧 Development

### Install Dependencies

```bash
# LLM Service
cd llm-service && npm install

# Backend
cd ../backend && npm install

# Frontend
cd ../frontend && npm install
```

### Environment Variables

See `.env.example` files in each service directory for required variables.

### Run Locally

```bash
# Terminal 1: LLM Service (port 8080)
cd llm-service && npm run dev

# Terminal 2: Backend (port 3000)
cd backend && npm run dev

# Terminal 3: Frontend (port 3000, React default)
cd frontend && npm start
```

## 🚢 Deployment

### Automated Deployment

```bash
export GCP_PROJECT_ID="your-project-id"
./setup-secrets.sh
./deploy.sh
```

### Manual Deployment

See [DEPLOYMENT.md](./DEPLOYMENT.md) for step-by-step instructions.

## 📊 API Endpoints

### Backend API

- `POST /api/process-transcript` - Process transcript and extract structured data
- `POST /api/sync/calendar` - Sync action items to Google Calendar
- `POST /api/sync/sheets` - Sync action items to Google Sheets
- `POST /api/sync/email` - Send summary email via Gmail
- `GET /api/meetings/:meetingId` - Get meeting by ID
- `GET /health` - Health check

### LLM Service

- `POST /extract` - Extract structured data from transcript
- `GET /health` - Health check

## 🔐 Security

- OAuth 2.0 for user authentication
- Secrets stored in Google Secret Manager
- User-scoped data in Firestore
- HTTPS only (Cloud Run default)
- CORS protection

## 📈 Roadmap

- [ ] Real-time transcript processing
- [ ] Multi-language support
- [ ] Custom LLM models (Gemma on GPU)
- [ ] Slack/Teams integration
- [ ] Advanced analytics dashboard
- [ ] Voice-to-text integration

## 🤝 Contributing

This is a hackathon project. For improvements, please open an issue or submit a PR.

## 📝 License

MIT

## 🙏 Acknowledgments

- Google Gemini API for AI capabilities
- Google Cloud Platform for infrastructure
- React community for excellent tooling

