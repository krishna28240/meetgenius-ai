# Quick Start Guide

Get MeetGenius AI running locally in 5 minutes!

## Prerequisites

- Node.js 18+ installed
- npm or yarn
- Gemini API key ([Get one here](https://makersuite.google.com/app/apikey))

## Local Setup

### 1. Clone and Install

```bash
cd meetgenius-ai

# Install LLM service dependencies
cd llm-service
npm install
cd ..

# Install backend dependencies
cd backend
npm install
cd ..

# Install frontend dependencies
cd frontend
npm install
cd ..
```

### 2. Configure Environment Variables

**LLM Service** (`llm-service/.env`):
```
PORT=8080
GEMINI_API_KEY=your-gemini-api-key-here
```

**Backend** (`backend/.env`):
```
PORT=3000
GCP_PROJECT_ID=your-gcp-project-id
LLM_SERVICE_URL=http://localhost:8080
GOOGLE_CLIENT_ID=586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URI=http://localhost:3000/auth/callback
```

**Frontend** (`frontend/.env`):
```
REACT_APP_API_URL=http://localhost:3000
REACT_APP_GOOGLE_CLIENT_ID=586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com
```

### 3. Set Up Firebase (for local backend)

```bash
# Install Firebase CLI if not already installed
npm install -g firebase-tools

# Login and initialize
firebase login
firebase init firestore

# Or use Application Default Credentials
gcloud auth application-default login
```

### 4. Start Services

Open 3 terminal windows:

**Terminal 1 - LLM Service:**
```bash
cd llm-service
npm run dev
```

**Terminal 2 - Backend:**
```bash
cd backend
npm run dev
```

**Terminal 3 - Frontend:**
```bash
cd frontend
npm start
```

### 5. Test the Application

1. Open http://localhost:3000 in your browser
2. Sign in with Google
3. Grant permissions for Calendar, Gmail, and Sheets
4. Upload a sample transcript from `samples/` folder
5. View the generated summary
6. Test syncing to Google services

## Troubleshooting

### "LLM Service not responding"
- Check that LLM service is running on port 8080
- Verify GEMINI_API_KEY is set correctly
- Check LLM service logs

### "OAuth errors"
- Verify OAuth redirect URI matches: `http://localhost:3000`
- Check Google Cloud Console credentials
- Ensure client ID and secret are correct

### "Firestore errors"
- Run `gcloud auth application-default login`
- Verify GCP_PROJECT_ID is set correctly
- Check Firestore is enabled in GCP Console

### "CORS errors"
- Ensure backend CORS is configured
- Check API URLs match in frontend .env

## Next Steps

- Deploy to Cloud Run (see `DEPLOYMENT.md`)
- Customize the LLM prompt in `backend/prompts/meeting_extractor.txt`
- Add more features to the frontend
- Integrate with additional Google services

## Sample Transcripts

Test with sample transcripts in the `samples/` folder:
- `sample-transcript-1.txt` - Team sync meeting
- `sample-transcript-2.txt` - Product review
- `sample-transcript-3.txt` - Sprint planning

