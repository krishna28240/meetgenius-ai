# MeetGenius AI - Complete Deployment Steps

This document provides step-by-step instructions for deploying MeetGenius AI to Google Cloud Platform.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Install Google Cloud SDK](#install-google-cloud-sdk)
3. [Authentication Setup](#authentication-setup)
4. [Project Configuration](#project-configuration)
5. [Enable Required APIs](#enable-required-apis)
6. [Set Up Firestore](#set-up-firestore)
7. [Configure Secrets](#configure-secrets)
8. [Deploy Services](#deploy-services)
9. [Configure OAuth](#configure-oauth)
10. [Test Deployment](#test-deployment)
11. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Tools

- **Google Cloud SDK** (gcloud CLI)
- **Node.js 18+** and npm
- **Git** (for cloning the repository)
- **A GCP Project** with billing enabled

### Required Information

- **Project ID**: `meetgenius-ai`
- **Gemini API Key**: `AIzaSyCpTFDBuJn2hNY8d-XMihkn4GBVWapU2w4`
- **OAuth Client ID**: `586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com`
- **OAuth Client Secret**: `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`

---

## Install Google Cloud SDK

### Option 1: Using Homebrew (macOS - Recommended)

```bash
brew install --cask google-cloud-sdk
```

### Option 2: Using the Installer Script

```bash
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
```

### Option 3: Manual Installation

Download from: https://cloud.google.com/sdk/docs/install

### Verify Installation

```bash
gcloud --version
```

---

## Authentication Setup

### 1. Login to Google Cloud

```bash
gcloud auth login
```

This will open a browser window. Sign in with your Google account that has access to the GCP project.

### 2. Set Up Application Default Credentials

```bash
gcloud auth application-default login
```

This is required for Firestore and other Google Cloud services to work locally.

### 3. Initialize gcloud (Optional)

```bash
gcloud init
```

Follow the prompts:
- Select your project: `meetgenius-ai`
- Choose default region: `us-central1`

---

## Project Configuration

### Set the Active Project

```bash
gcloud config set project meetgenius-ai
```

### Verify Project Settings

```bash
gcloud config list
```

You should see:
- `project = meetgenius-ai`
- `region = us-central1` (or your preferred region)

---

## Enable Required APIs

Enable all required Google Cloud APIs with a single command:

```bash
gcloud services enable \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com \
  iam.googleapis.com \
  sheets.googleapis.com \
  gmail.googleapis.com \
  calendar-json.googleapis.com \
  drive.googleapis.com \
  secretmanager.googleapis.com \
  firestore.googleapis.com \
  aiplatform.googleapis.com \
  --project=meetgenius-ai
```

### Verify APIs are Enabled

```bash
gcloud services list --enabled --project=meetgenius-ai
```

You should see all the above APIs listed.

---

## Set Up Firestore

### Create Firestore Database

1. **Via Console** (Recommended for first-time setup):
   - Go to: https://console.cloud.google.com/firestore?project=meetgenius-ai
   - Click "Create database"
   - Select "Native mode"
   - Choose region: `us-central1` (or your preferred region)
   - Click "Create"

2. **Via Command Line**:
   ```bash
   gcloud firestore databases create \
     --location=us-central1 \
     --type=firestore-native \
     --project=meetgenius-ai
   ```

### Verify Database Created

```bash
gcloud firestore databases list --project=meetgenius-ai
```

---

## Configure Secrets

Store sensitive information in Google Secret Manager.

### 1. Create Gemini API Key Secret

```bash
echo -n "AIzaSyCpTFDBuJn2hNY8d-XMihkn4GBVWapU2w4" | \
  gcloud secrets create gemini-api-key \
  --data-file=- \
  --project=meetgenius-ai
```

If the secret already exists, add a new version:

```bash
echo -n "AIzaSyCpTFDBuJn2hNY8d-XMihkn4GBVWapU2w4" | \
  gcloud secrets versions add gemini-api-key \
  --data-file=- \
  --project=meetgenius-ai
```

### 2. Create OAuth Client ID Secret

```bash
echo -n "586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com" | \
  gcloud secrets create google-client-id \
  --data-file=- \
  --project=meetgenius-ai
```

Or update existing:

```bash
echo -n "586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com" | \
  gcloud secrets versions add google-client-id \
  --data-file=- \
  --project=meetgenius-ai
```

### 3. Create OAuth Client Secret

```bash
echo -n "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" | \
  gcloud secrets create google-client-secret \
  --data-file=- \
  --project=meetgenius-ai
```

Or update existing:

```bash
echo -n "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" | \
  gcloud secrets versions add google-client-secret \
  --data-file=- \
  --project=meetgenius-ai
```

### 4. Grant Service Account Access to Secrets

```bash
SERVICE_ACCOUNT="meetgenius-ai@appspot.gserviceaccount.com"

# Grant access to Gemini API key
gcloud secrets add-iam-policy-binding gemini-api-key \
  --member="serviceAccount:${SERVICE_ACCOUNT}" \
  --role="roles/secretmanager.secretAccessor" \
  --project=meetgenius-ai

# Grant access to OAuth Client ID
gcloud secrets add-iam-policy-binding google-client-id \
  --member="serviceAccount:${SERVICE_ACCOUNT}" \
  --role="roles/secretmanager.secretAccessor" \
  --project=meetgenius-ai

# Grant access to OAuth Client Secret
gcloud secrets add-iam-policy-binding google-client-secret \
  --member="serviceAccount:${SERVICE_ACCOUNT}" \
  --role="roles/secretmanager.secretAccessor" \
  --project=meetgenius-ai
```

### 5. Verify Secrets

```bash
gcloud secrets list --project=meetgenius-ai
```

You should see:
- `gemini-api-key`
- `google-client-id`
- `google-client-secret`

---

## Deploy Services

Deploy services in order: LLM Service → Backend → Frontend

### Step 1: Deploy LLM Service

```bash
cd llm-service

# Build and push container image
gcloud builds submit --tag gcr.io/meetgenius-ai/meetgenius-llm --project=meetgenius-ai

# Deploy to Cloud Run
gcloud run deploy meetgenius-llm \
  --image gcr.io/meetgenius-ai/meetgenius-llm \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 2 \
  --set-secrets GEMINI_API_KEY=gemini-api-key:latest \
  --project=meetgenius-ai

# Get the service URL
LLM_URL=$(gcloud run services describe meetgenius-llm \
  --region us-central1 \
  --format 'value(status.url)' \
  --project=meetgenius-ai)

echo "LLM Service URL: $LLM_URL"

cd ..
```

**Save the LLM URL** - you'll need it for the next step.

### Step 2: Deploy Backend Service

```bash
cd backend

# Build and push container image
gcloud builds submit --tag gcr.io/meetgenius-ai/meetgenius-backend --project=meetgenius-ai

# Deploy to Cloud Run (replace $LLM_URL with the actual URL from Step 1)
gcloud run deploy meetgenius-backend \
  --image gcr.io/meetgenius-ai/meetgenius-backend \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 1Gi \
  --cpu 1 \
  --set-env-vars LLM_SERVICE_URL=$LLM_URL,GCP_PROJECT_ID=meetgenius-ai \
  --set-secrets GOOGLE_CLIENT_ID=google-client-id:latest,GOOGLE_CLIENT_SECRET=google-client-secret:latest \
  --project=meetgenius-ai

# Get the service URL
BACKEND_URL=$(gcloud run services describe meetgenius-backend \
  --region us-central1 \
  --format 'value(status.url)' \
  --project=meetgenius-ai)

echo "Backend Service URL: $BACKEND_URL"

cd ..
```

**Save the Backend URL** - you'll need it for the next step.

### Step 3: Deploy Frontend Service

```bash
cd frontend

# Create production environment file
cat > .env.production << EOF
REACT_APP_API_URL=$BACKEND_URL
REACT_APP_GOOGLE_CLIENT_ID=586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com
EOF

# Install dependencies (if not already installed)
npm install

# Build the React app
npm run build

# Deploy to Cloud Run
gcloud run deploy meetgenius-frontend \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --project=meetgenius-ai

# Get the service URL
FRONTEND_URL=$(gcloud run services describe meetgenius-frontend \
  --region us-central1 \
  --format 'value(status.url)' \
  --project=meetgenius-ai)

echo "Frontend Service URL: $FRONTEND_URL"

cd ..
```

**Save the Frontend URL** - you'll need it for OAuth configuration.

---

## Configure OAuth

After deployment, update OAuth redirect URIs with your actual frontend URL.

### 1. Navigate to OAuth Credentials

Go to: https://console.cloud.google.com/apis/credentials?project=meetgenius-ai

### 2. Edit OAuth 2.0 Client ID

Click on the OAuth 2.0 Client ID: `586594156466-03b76ajqn70gkbsoia34g887edb6kqlm`

### 3. Add Authorized Redirect URIs

Add the following URIs:
- `http://localhost:3000` (for local testing)
- `YOUR_FRONTEND_URL` (the URL from Step 3 above, e.g., `https://meetgenius-frontend-xxx.run.app`)

### 4. Add Authorized JavaScript Origins

Add the following origins:
- `http://localhost:3000` (for local testing)
- `YOUR_FRONTEND_URL` (the URL from Step 3 above)

### 5. Save Changes

Click "Save" to apply the changes.

---

## Test Deployment

### 1. Access the Frontend

Open your browser and navigate to your Frontend URL (from Step 3 above).

### 2. Sign In

- Click "Sign in with Google"
- Select your Google account
- Grant permissions for Calendar, Gmail, and Sheets

### 3. Test Transcript Processing

1. Click "Upload Meeting Transcript"
2. Either:
   - Paste a transcript in the text area, or
   - Upload a file from the `samples/` folder
3. Optionally enter a meeting title
4. Click "Generate Summary"
5. Wait for the AI to process the transcript
6. Review the generated summary, decisions, and action items

### 4. Test Calendar Sync

1. In the "Sync Actions" panel, check "📅 Google Calendar"
2. Click "Run Sync Now"
3. Verify calendar events were created in your Google Calendar

### 5. Test Sheets Sync

1. In the "Sync Actions" panel, check "📊 Google Sheets"
2. Click "Run Sync Now"
3. A new Google Sheet should be created with action items
4. Check your Google Drive for the sheet

### 6. Test Email Sync

1. In the "Sync Actions" panel, check "✉️ Gmail"
2. Click "Run Sync Now"
3. Check your Gmail inbox for the summary email
4. Verify all participants received the email

---

## Quick Deployment (Automated)

If you prefer an automated approach, use the provided script:

```bash
# Make sure you're authenticated first
gcloud auth login
gcloud auth application-default login

# Run the automated deployment script
./deploy-all.sh
```

This script will:
- Set the GCP project
- Enable all required APIs
- Create Firestore database
- Set up all secrets
- Deploy all three services
- Display all service URLs

**Remember**: You still need to manually update OAuth redirect URIs after deployment.

---

## Troubleshooting

### Check Service Logs

```bash
# LLM Service logs
gcloud run services logs read meetgenius-llm \
  --region us-central1 \
  --project=meetgenius-ai \
  --limit=50

# Backend logs
gcloud run services logs read meetgenius-backend \
  --region us-central1 \
  --project=meetgenius-ai \
  --limit=50

# Frontend logs
gcloud run services logs read meetgenius-frontend \
  --region us-central1 \
  --project=meetgenius-ai \
  --limit=50
```

### Verify Service Status

```bash
gcloud run services list \
  --project=meetgenius-ai \
  --region=us-central1
```

### Test Service Endpoints

```bash
# Test LLM Service health
curl https://meetgenius-llm-xxx.run.app/health

# Test Backend health
curl https://meetgenius-backend-xxx.run.app/health
```

### Common Issues

#### Issue: "gcloud: command not found"

**Solution**: Install Google Cloud SDK (see [Install Google Cloud SDK](#install-google-cloud-sdk))

#### Issue: "Permission denied" errors

**Solution**: 
- Ensure you're authenticated: `gcloud auth login`
- Verify project access: `gcloud projects list`
- Check IAM roles in the GCP Console

#### Issue: "API not enabled" errors

**Solution**: Run the enable APIs command again (see [Enable Required APIs](#enable-required-apis))

#### Issue: "Secret not found" errors

**Solution**: 
- Verify secrets exist: `gcloud secrets list --project=meetgenius-ai`
- Check service account has access (see [Configure Secrets](#configure-secrets))

#### Issue: OAuth redirect URI mismatch

**Solution**: 
- Update OAuth redirect URIs in Google Cloud Console
- Ensure frontend URL is added to authorized redirect URIs and JavaScript origins

#### Issue: Firestore permission denied

**Solution**: 
- Ensure Firestore database is created
- Verify Application Default Credentials: `gcloud auth application-default login`
- Check Firestore rules in the console

#### Issue: LLM service timeout

**Solution**: 
- Check Gemini API quota and billing
- Verify API key is correct
- Check LLM service logs for errors

### Verify Secrets

```bash
# List all secrets
gcloud secrets list --project=meetgenius-ai

# Verify a secret exists
gcloud secrets describe gemini-api-key --project=meetgenius-ai

# Check service account access
gcloud secrets get-iam-policy gemini-api-key --project=meetgenius-ai
```

### Check Build Logs

```bash
# View recent Cloud Build history
gcloud builds list --project=meetgenius-ai --limit=10

# View specific build logs
gcloud builds log BUILD_ID --project=meetgenius-ai
```

---

## Service URLs Reference

After deployment, save these URLs:

- **Frontend**: `https://meetgenius-frontend-xxx.run.app`
- **Backend**: `https://meetgenius-backend-xxx.run.app`
- **LLM Service**: `https://meetgenius-llm-xxx.run.app`

Replace `xxx` with your actual Cloud Run service IDs.

---

## Post-Deployment Checklist

- [ ] All three services deployed successfully
- [ ] OAuth redirect URIs updated
- [ ] Tested transcript processing
- [ ] Tested Calendar sync
- [ ] Tested Sheets sync
- [ ] Tested Gmail sync
- [ ] Service logs checked (no errors)
- [ ] All service URLs documented

---

## Environment Variables Reference

### LLM Service
- `GEMINI_API_KEY` - From Secret Manager
- `PORT` - Default: 8080

### Backend
- `LLM_SERVICE_URL` - LLM service Cloud Run URL
- `GCP_PROJECT_ID` - meetgenius-ai
- `GOOGLE_CLIENT_ID` - From Secret Manager
- `GOOGLE_CLIENT_SECRET` - From Secret Manager
- `PORT` - Default: 3000

### Frontend
- `REACT_APP_API_URL` - Backend Cloud Run URL
- `REACT_APP_GOOGLE_CLIENT_ID` - OAuth client ID

---

## Next Steps

After successful deployment:

1. **Monitor Services**: Set up Cloud Monitoring alerts
2. **Customize Prompts**: Edit `backend/prompts/meeting_extractor.txt`
3. **Add Features**: Extend functionality as needed
4. **Set Up CI/CD**: Automate deployments with Cloud Build
5. **Configure Domain**: Set up custom domain (optional)
6. **Scale Resources**: Adjust Cloud Run resources based on usage

---

## Support

For issues or questions:
- Check service logs (see [Troubleshooting](#troubleshooting))
- Review [ARCHITECTURE.md](./ARCHITECTURE.md) for system design
- Check [QUICKSTART.md](./QUICKSTART.md) for local development setup

---

## Summary

This deployment process:
1. ✅ Sets up GCP project and authentication
2. ✅ Enables all required APIs
3. ✅ Creates Firestore database
4. ✅ Configures secrets securely
5. ✅ Deploys LLM service
6. ✅ Deploys Backend service
7. ✅ Deploys Frontend service
8. ✅ Configures OAuth
9. ✅ Tests all functionality

**Total deployment time**: Approximately 15-20 minutes (depending on build times)

---

*Last updated: January 2025*

