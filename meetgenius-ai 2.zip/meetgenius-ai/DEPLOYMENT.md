# Deployment Guide

Complete guide for deploying MeetGenius AI to Google Cloud Platform.

## Prerequisites

1. GCP Project with billing enabled
2. `gcloud` CLI installed and authenticated
3. Node.js 18+ installed
4. Gemini API key

## Step 1: Initial Setup

```bash
# Set your project ID
export GCP_PROJECT_ID="your-project-id"
gcloud config set project $GCP_PROJECT_ID
```

## Step 2: Enable APIs

```bash
gcloud services enable \
  run.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com \
  secretmanager.googleapis.com \
  firestore.googleapis.com \
  sheets.googleapis.com \
  gmail.googleapis.com \
  calendar-json.googleapis.com \
  drive.googleapis.com
```

## Step 3: Set Up Secrets

```bash
./setup-secrets.sh
```

Or manually:

```bash
# Gemini API Key
echo -n "your-gemini-api-key" | gcloud secrets create gemini-api-key --data-file=-

# OAuth Credentials (already provided)
echo -n "586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com" | \
  gcloud secrets create google-client-id --data-file=-

echo -n "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" | \
  gcloud secrets create google-client-secret --data-file=-
```

## Step 4: Configure Firestore

1. Go to [Firestore Console](https://console.cloud.google.com/firestore)
2. Create database in Native mode
3. Select region (e.g., us-central1)
4. The backend will automatically create the `meetings` collection

## Step 5: Deploy Services

### Option A: Automated Deployment

```bash
./deploy.sh
```

### Option B: Manual Deployment

#### Deploy LLM Service

```bash
cd llm-service
gcloud builds submit --tag gcr.io/$GCP_PROJECT_ID/meetgenius-llm

gcloud run deploy meetgenius-llm \
  --image gcr.io/$GCP_PROJECT_ID/meetgenius-llm \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 2 \
  --set-secrets GEMINI_API_KEY=gemini-api-key:latest

# Note the service URL
LLM_URL=$(gcloud run services describe meetgenius-llm --region us-central1 --format 'value(status.url)')
```

#### Deploy Backend

```bash
cd ../backend
gcloud builds submit --tag gcr.io/$GCP_PROJECT_ID/meetgenius-backend

gcloud run deploy meetgenius-backend \
  --image gcr.io/$GCP_PROJECT_ID/meetgenius-backend \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 1Gi \
  --cpu 1 \
  --set-env-vars LLM_SERVICE_URL=$LLM_URL,GCP_PROJECT_ID=$GCP_PROJECT_ID \
  --set-secrets GOOGLE_CLIENT_ID=google-client-id:latest,GOOGLE_CLIENT_SECRET=google-client-secret:latest

BACKEND_URL=$(gcloud run services describe meetgenius-backend --region us-central1 --format 'value(status.url)')
```

#### Deploy Frontend

```bash
cd ../frontend
npm install
npm run build

# Update .env.production with BACKEND_URL
echo "REACT_APP_API_URL=$BACKEND_URL" > .env.production
echo "REACT_APP_GOOGLE_CLIENT_ID=586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com" >> .env.production

npm run build

gcloud run deploy meetgenius-frontend \
  --source . \
  --region us-central1 \
  --allow-unauthenticated
```

## Step 6: Configure OAuth

1. Go to [Google Cloud Console > APIs & Services > Credentials](https://console.cloud.google.com/apis/credentials)
2. Edit your OAuth 2.0 Client ID
3. Add authorized redirect URIs:
   - `http://localhost:3000` (for local dev)
   - `https://meetgenius-frontend-xxx.run.app` (your Cloud Run frontend URL)
4. Add authorized JavaScript origins:
   - `http://localhost:3000`
   - `https://meetgenius-frontend-xxx.run.app`

## Step 7: Test Deployment

1. Visit your frontend URL
2. Sign in with Google
3. Upload a sample transcript from `samples/` folder
4. Verify summary generation
5. Test sync to Calendar, Sheets, and Gmail

## Troubleshooting

### LLM Service Issues
- Check Gemini API key in Secret Manager
- Verify API quota and billing

### Backend Issues
- Check Firestore permissions
- Verify LLM service URL is correct
- Check OAuth credentials in Secret Manager

### Frontend Issues
- Verify API URL environment variable
- Check OAuth redirect URIs match
- Check browser console for errors

### Permission Errors
- Ensure service account has Secret Manager accessor role
- Verify Firestore permissions
- Check Google API scopes are granted

## Monitoring

View logs:
```bash
# LLM Service
gcloud run services logs read meetgenius-llm --region us-central1

# Backend
gcloud run services logs read meetgenius-backend --region us-central1

# Frontend
gcloud run services logs read meetgenius-frontend --region us-central1
```

## Cost Optimization

- Use Cloud Run's min-instances=0 for cost savings
- Set max-instances based on expected load
- Monitor API quotas (Gemini API has usage limits)
- Use Firestore's free tier when possible

