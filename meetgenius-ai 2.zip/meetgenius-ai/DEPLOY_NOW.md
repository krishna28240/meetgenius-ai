# 🚀 Quick Deployment Guide

## Prerequisites

1. **Install Google Cloud SDK** (if not installed):
   ```bash
   # macOS
   brew install google-cloud-sdk
   
   # Or download from: https://cloud.google.com/sdk/docs/install
   ```

2. **Authenticate**:
   ```bash
   gcloud auth login
   gcloud auth application-default login
   ```

## One-Command Deployment

Run this single script to deploy everything:

```bash
./deploy-all.sh
```

This script will:
- ✅ Set GCP project to `meetgenius-ai`
- ✅ Enable all required APIs
- ✅ Create Firestore database
- ✅ Set up secrets in Secret Manager
- ✅ Deploy LLM service
- ✅ Deploy Backend service
- ✅ Deploy Frontend service
- ✅ Display all service URLs

## Manual Step: Update OAuth Redirect URIs

After deployment, you **must** update OAuth settings:

1. Go to: https://console.cloud.google.com/apis/credentials?project=meetgenius-ai
2. Click on OAuth 2.0 Client ID: `586594156466-03b76ajqn70gkbsoia34g887edb6kqlm`
3. Add **Authorized redirect URIs**:
   - Your frontend URL (shown at end of deployment)
   - `http://localhost:3000` (for local testing)
4. Add **Authorized JavaScript origins**:
   - Your frontend URL
   - `http://localhost:3000`
5. Click **Save**

## Test Your Deployment

1. Visit your frontend URL (shown at end of deployment)
2. Click "Sign in with Google"
3. Grant permissions for Calendar, Gmail, and Sheets
4. Upload a sample transcript from `samples/` folder
5. View the generated summary
6. Test syncing to Google services

## Troubleshooting

### Check Service Logs

```bash
# LLM Service
gcloud run services logs read meetgenius-llm --region us-central1 --project meetgenius-ai

# Backend
gcloud run services logs read meetgenius-backend --region us-central1 --project meetgenius-ai

# Frontend
gcloud run services logs read meetgenius-frontend --region us-central1 --project meetgenius-ai
```

### Verify Services

```bash
gcloud run services list --project meetgenius-ai --region us-central1
```

### Check Secrets

```bash
gcloud secrets list --project meetgenius-ai
```

## What's Configured

- **Project ID**: meetgenius-ai
- **Region**: us-central1
- **Gemini API Key**: Already configured in secrets
- **OAuth Credentials**: Already configured
- **All APIs**: Enabled automatically

## Next Steps After Deployment

1. ✅ Update OAuth redirect URIs (required!)
2. Test with sample transcripts
3. Customize prompts if needed
4. Set up monitoring (optional)

