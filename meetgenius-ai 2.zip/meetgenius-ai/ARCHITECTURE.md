# MeetGenius AI - Architecture Overview

## System Architecture

```
┌─────────────────┐
│   React Frontend │
│  (Cloud Run)     │
└────────┬─────────┘
         │ HTTPS
         ▼
┌─────────────────┐
│  Backend API    │
│  (Cloud Run)    │
│  - Express.js   │
│  - OAuth        │
│  - Google APIs  │
└────────┬─────────┘
         │
    ┌────┴────┐
    │         │
    ▼         ▼
┌─────────┐ ┌──────────────┐
│ LLM     │ │  Firestore   │
│ Service │ │  Database    │
│(Gemini) │ └──────────────┘
└─────────┘
    │
    ▼
┌─────────────────────────────┐
│      Google APIs            │
│  - Calendar API             │
│  - Gmail API               │
│  - Sheets API              │
│  - Drive API               │
└─────────────────────────────┘
```

## Components

### 1. Frontend (React)
- **Location**: `/frontend`
- **Technology**: React 18, CSS3
- **Deployment**: Cloud Run (static hosting) or Firebase Hosting
- **Features**:
  - Google OAuth authentication
  - Transcript upload (text/file)
  - Summary visualization
  - Sync controls

### 2. Backend API (Node.js/Express)
- **Location**: `/backend`
- **Technology**: Express.js, Google APIs SDK, Firebase Admin
- **Deployment**: Cloud Run
- **Endpoints**:
  - `POST /api/process-transcript` - Process transcript via LLM
  - `POST /api/sync/calendar` - Sync to Google Calendar
  - `POST /api/sync/sheets` - Sync to Google Sheets
  - `POST /api/sync/email` - Send email via Gmail
  - `GET /api/meetings/:id` - Retrieve meeting data

### 3. LLM Service (Gemini)
- **Location**: `/llm-service`
- **Technology**: Node.js, Google Generative AI SDK
- **Deployment**: Cloud Run
- **Function**: Extract structured data from transcripts
- **Output**: JSON with title, summary, decisions, action items, participants

### 4. Firestore Database
- **Collection**: `meetings`
- **Schema**:
  ```json
  {
    "userId": "string",
    "userEmail": "string",
    "title": "string",
    "summary": "string",
    "decisions": [{"decision": "string", "context": "string"}],
    "actionItems": [{"task": "string", "assignee": "string", "due_date": "string", "priority": "string", "confidence": "number"}],
    "participants": [{"name": "string", "email": "string", "role": "string"}],
    "createdAt": "timestamp",
    "synced": {"calendar": "boolean", "sheets": "boolean", "email": "boolean"}
  }
  ```

### 5. Secret Manager
- **Secrets**:
  - `gemini-api-key` - Gemini API key
  - `google-client-id` - OAuth client ID
  - `google-client-secret` - OAuth client secret

## Data Flow

1. **Transcript Processing**:
   ```
   User → Frontend → Backend → LLM Service → Backend → Firestore
   ```

2. **Calendar Sync**:
   ```
   User → Frontend → Backend → Google Calendar API → Firestore (update sync status)
   ```

3. **Sheets Sync**:
   ```
   User → Frontend → Backend → Google Sheets API → Firestore (update sync status)
   ```

4. **Email Sync**:
   ```
   User → Frontend → Backend → Gmail API → Firestore (update sync status)
   ```

## Security

- **Authentication**: Google OAuth 2.0
- **Authorization**: User-scoped data in Firestore
- **Secrets**: Stored in Google Secret Manager
- **API Security**: Cloud Run IAM, OAuth tokens
- **Data Privacy**: User data isolated by userId

## Scalability

- **Cloud Run**: Auto-scales based on traffic
- **Firestore**: Handles concurrent reads/writes
- **LLM Service**: Stateless, can scale horizontally
- **Rate Limiting**: Consider adding for production

## Monitoring

- **Cloud Logging**: All services log to Stackdriver
- **Error Tracking**: Express error handlers
- **Metrics**: Cloud Run provides request metrics
- **Alerts**: Can be configured in Cloud Monitoring

## Cost Optimization

- **Cloud Run**: Pay per request, scales to zero
- **Firestore**: Free tier: 50K reads, 20K writes/day
- **Gemini API**: Pay per token (check current pricing)
- **Google APIs**: Free tier available for most APIs

## Future Enhancements

1. Real-time transcript processing (WebSocket)
2. Multi-language support
3. Custom LLM models (Gemma on GPU)
4. Advanced analytics dashboard
5. Team collaboration features
6. Integration with Slack, Microsoft Teams
7. Voice-to-text integration
8. Meeting recording analysis

