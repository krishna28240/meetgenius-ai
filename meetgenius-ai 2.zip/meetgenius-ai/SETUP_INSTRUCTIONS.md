# MeetGenius AI - Setup Instructions

Follow these steps to deploy MeetGenius AI to GCP.

## Prerequisites

1. Install Google Cloud SDK: https://cloud.google.com/sdk/docs/install
2. Authenticate: `gcloud auth login`
3. Set up Application Default Credentials: `gcloud auth application-default login`

## Step 1: Set GCP Project

```bash
gcloud config set project meetgenius-ai
```

## Step 2: Enable Required APIs

```bash
gcloud services enable \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com \
  iam.googleapis.com \
  sheets.googleapis.com \
  gmail.googleapis.com \
  calendar-json.googleapis.com \
  drive.googleapis.com \
  secretmanager.googleapis.com \
  firestore.googleapis.com \
  aiplatform.googleapis.com
```

Verify APIs are enabled:
```bash
gcloud services list --enabled
```

## Step 3: Set Up Firestore

1. Go to [Firestore Console](https://console.cloud.google.com/firestore?project=meetgenius-ai)
2. Click "Create database"
3. Select "Native mode"
4. Choose region (e.g., `us-central1`)
5. Click "Create"

## Step 4: Configure OAuth

1. Go to [APIs & Services > Credentials](https://console.cloud.google.com/apis/credentials?project=meetgenius-ai)
2. Find your OAuth 2.0 Client ID: `586594156466-03b76ajqn70gkbsoia34g887edb6kqlm`
3. Click Edit
4. Add Authorized redirect URIs:
   - `http://localhost:3000` (for local testing)
   - `https://meetgenius-frontend-*.run.app` (will be updated after deployment)
5. Add Authorized JavaScript origins:
   - `http://localhost:3000`
   - `https://meetgenius-frontend-*.run.app` (will be updated after deployment)
6. Save

## Step 5: Set Up Secrets

```bash
chmod +x setup-secrets.sh
./setup-secrets.sh
```

This script will:
- Store Gemini API key in Secret Manager
- Store OAuth client ID in Secret Manager
- Store OAuth client secret in Secret Manager
- Grant Cloud Run service account access to secrets

## Step 6: Deploy Services

```bash
chmod +x deploy.sh
./deploy.sh
```

Or deploy manually:

### Deploy LLM Service

```bash
cd llm-service
gcloud builds submit --tag gcr.io/meetgenius-ai/meetgenius-llm

gcloud run deploy meetgenius-llm \
  --image gcr.io/meetgenius-ai/meetgenius-llm \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 2 \
  --set-secrets GEMINI_API_KEY=gemini-api-key:latest \
  --project meetgenius-ai

# Get LLM service URL
LLM_URL=$(gcloud run services describe meetgenius-llm --region us-central1 --format 'value(status.url)' --project meetgenius-ai)
echo "LLM Service URL: $LLM_URL"
```

### Deploy Backend

```bash
cd ../backend
gcloud builds submit --tag gcr.io/meetgenius-ai/meetgenius-backend

gcloud run deploy meetgenius-backend \
  --image gcr.io/meetgenius-ai/meetgenius-backend \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 1Gi \
  --cpu 1 \
  --set-env-vars LLM_SERVICE_URL=$LLM_URL,GCP_PROJECT_ID=meetgenius-ai \
  --set-secrets GOOGLE_CLIENT_ID=google-client-id:latest,GOOGLE_CLIENT_SECRET=google-client-secret:latest \
  --project meetgenius-ai

# Get Backend URL
BACKEND_URL=$(gcloud run services describe meetgenius-backend --region us-central1 --format 'value(status.url)' --project meetgenius-ai)
echo "Backend URL: $BACKEND_URL"
```

### Deploy Frontend

```bash
cd ../frontend

# Create .env.production with backend URL
cat > .env.production << EOF
REACT_APP_API_URL=$BACKEND_URL
REACT_APP_GOOGLE_CLIENT_ID=586594156466-03b76ajqn70gkbsoia34g887edb6kqlm.apps.googleusercontent.com
EOF

npm install
npm run build

gcloud run deploy meetgenius-frontend \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --project meetgenius-ai

# Get Frontend URL
FRONTEND_URL=$(gcloud run services describe meetgenius-frontend --region us-central1 --format 'value(status.url)' --project meetgenius-ai)
echo "Frontend URL: $FRONTEND_URL"
```

## Step 7: Update OAuth Redirect URIs

After deployment, update the OAuth redirect URIs with the actual frontend URL:

1. Go to [APIs & Services > Credentials](https://console.cloud.google.com/apis/credentials?project=meetgenius-ai)
2. Edit your OAuth 2.0 Client ID
3. Add the frontend URL from Step 6 to Authorized redirect URIs and JavaScript origins
4. Save

## Step 8: Test Deployment

1. Visit your frontend URL
2. Sign in with Google
3. Grant permissions for Calendar, Gmail, and Sheets
4. Upload a sample transcript from `samples/` folder
5. View the generated summary
6. Test syncing to Google services

## Troubleshooting

### Check Service Logs

```bash
# LLM Service
gcloud run services logs read meetgenius-llm --region us-central1 --project meetgenius-ai

# Backend
gcloud run services logs read meetgenius-backend --region us-central1 --project meetgenius-ai

# Frontend
gcloud run services logs read meetgenius-frontend --region us-central1 --project meetgenius-ai
```

### Verify Secrets

```bash
gcloud secrets list --project meetgenius-ai
gcloud secrets versions access latest --secret=gemini-api-key --project meetgenius-ai
```

### Check Service Status

```bash
gcloud run services list --project meetgenius-ai --region us-central1
```

## Environment Variables Reference

### LLM Service
- `GEMINI_API_KEY` - From Secret Manager
- `PORT` - Default: 8080

### Backend
- `LLM_SERVICE_URL` - LLM service Cloud Run URL
- `GCP_PROJECT_ID` - meetgenius-ai
- `GOOGLE_CLIENT_ID` - From Secret Manager
- `GOOGLE_CLIENT_SECRET` - From Secret Manager
- `PORT` - Default: 3000

### Frontend
- `REACT_APP_API_URL` - Backend Cloud Run URL
- `REACT_APP_GOOGLE_CLIENT_ID` - OAuth client ID

## Next Steps

- Test with sample transcripts
- Customize LLM prompts if needed
- Set up monitoring and alerts
- Configure custom domain (optional)


