# Install Google Cloud SDK and Deploy

## Quick Installation

Since `gcloud` is not currently installed, follow these steps:

### Option 1: Install via Homebrew (Recommended for macOS)

```bash
# Install Homebrew if not installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Google Cloud SDK
brew install --cask google-cloud-sdk

# Reload your shell
exec -l $SHELL
```

### Option 2: Install via Official Installer

```bash
# Download and install
curl https://sdk.cloud.google.com | bash

# Reload your shell
exec -l $SHELL
```

### Verify Installation

```bash
gcloud --version
```

You should see version information.

## After Installation

### 1. Authenticate

```bash
gcloud auth login
gcloud auth application-default login
```

### 2. Set Project

```bash
gcloud config set project meetgenius-ai
```

### 3. Run Deployment

```bash
./deploy-all.sh
```

Or follow the step-by-step guide in `DEPLOYMENT_STEPS.md`

---

## What the Deployment Script Does

The `deploy-all.sh` script will:

1. ✅ Check for gcloud installation
2. ✅ Set GCP project to `meetgenius-ai`
3. ✅ Enable all required APIs
4. ✅ Create Firestore database
5. ✅ Set up secrets (Gemini API key, OAuth credentials)
6. ✅ Deploy LLM service
7. ✅ Deploy Backend service
8. ✅ Deploy Frontend service
9. ✅ Display all service URLs

**Total time**: ~15-20 minutes

---

## Need Help?

See `DEPLOYMENT_STEPS.md` for detailed step-by-step instructions.


